package com.myvault.app

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object Crypto {
    private const val ITER = 310_000
    private const val CHUNK = 1 shl 20
    private val sr = SecureRandom()

    fun rnd(n: Int) = ByteArray(n).also { sr.nextBytes(it) }

    fun key(pw: CharArray, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(pw, salt, ITER, 256)
        try {
            val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            return SecretKeySpec(raw, "AES")
        } finally { spec.clearPassword() }
    }

    private fun cipher(mode: Int, k: SecretKey, iv: ByteArray) =
        Cipher.getInstance("AES/GCM/NoPadding").apply { init(mode, k, GCMParameterSpec(128, iv)) }

    fun seal(k: SecretKey, d: ByteArray): ByteArray {
        val iv = rnd(12)
        return iv + cipher(Cipher.ENCRYPT_MODE, k, iv).doFinal(d)
    }

    fun open(k: SecretKey, b: ByteArray): ByteArray =
        cipher(Cipher.DECRYPT_MODE, k, b.copyOf(12)).doFinal(b, 12, b.size - 12)

    fun readFully(i: InputStream, b: ByteArray, len: Int = b.size): Int {
        var n = 0
        while (n < len) {
            val r = i.read(b, n, len - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun iv(p: ByteArray, c: Int) = p + ByteBuffer.allocate(4).putInt(c).array()
    private fun aad(c: Int, last: Boolean) =
        ByteBuffer.allocate(5).putInt(c).put((if (last) 1 else 0).toByte()).array()

    // বড় ভিডিওর জন্য ১ MB করে টুকরো টুকরো এনক্রিপশন
    fun enc(k: SecretKey, inp: InputStream, out: OutputStream) {
        val p = rnd(8)
        out.write(p)
        val buf = ByteArray(CHUNK)
        var c = 0
        while (true) {
            val n = readFully(inp, buf)
            if (n == 0) break
            chunk(k, p, c++, buf, n, false, out)
        }
        chunk(k, p, c, buf, 0, true, out)
    }

    private fun chunk(k: SecretKey, p: ByteArray, c: Int, buf: ByteArray, n: Int, last: Boolean, out: OutputStream) {
        val ci = cipher(Cipher.ENCRYPT_MODE, k, iv(p, c))
        ci.updateAAD(aad(c, last))
        val ct = ci.doFinal(buf, 0, n)
        out.write(ByteBuffer.allocate(4).putInt(ct.size or (if (last) Int.MIN_VALUE else 0)).array())
        out.write(ct)
    }

    fun dec(k: SecretKey, inp: InputStream, out: OutputStream) {
        val p = ByteArray(8)
        if (readFully(inp, p) != 8) throw IOException("bad")
        var c = 0
        val h = ByteArray(4)
        while (true) {
            if (readFully(inp, h) != 4) throw IOException("truncated")
            val v = ByteBuffer.wrap(h).int
            val last = v < 0
            val len = v and Int.MAX_VALUE
            if (len < 16 || len > CHUNK + 16) throw IOException("bad")
            val ct = ByteArray(len)
            if (readFully(inp, ct) != len) throw IOException("truncated")
            val ci = cipher(Cipher.DECRYPT_MODE, k, iv(p, c))
            ci.updateAAD(aad(c, last))
            out.write(ci.doFinal(ct))
            if (last) break
            c++
        }
    }
}
