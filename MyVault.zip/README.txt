১) এই ফোল্ডারের সব ফাইল GitHub repo-তে আপলোড করুন (.github/workflows/build.yml সহ)।
   .github ফোল্ডার আপলোডে না এলে: Add file > Create new file > নাম লিখুন  .github/workflows/build.yml  > build.yml-এর লেখা পেস্ট করুন।
২) Actions ট্যাব > Build APK > শেষ হলে নিচে Artifacts থেকে MyVault-apk ডাউনলোড (zip খুলে app-debug.apk ইনস্টল)।
